import java.util.Scanner;
public class studentgradecalculator
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        float marks[]= new float[n];
        float sum=0,avg=0;
        int i;
        System.out.println("Enter the marks obtained in each subject out 100");
        for(i=0;i<n;i++)
        {
            marks[i]=sc.nextFloat();
            sum=sum+marks[i];
            avg=(sum)/n;
        }
        System.out.println("Total marks" +sum);
        System.out.println("Average percentage" +avg);
        System.out.println("Corresponding grade:");
        
        if(avg>90)
        System.out.println("O");
        else if(avg>=80 && avg<89)
        System.out.println("A+");
        else if(avg>=70 && avg<79)
        System.out.println("A");
        else if(avg>=60 && avg<69)
        System.out.println("B");
        else if(avg>=50 && avg<59)
        System.out.println("C");
        else if(avg>=40 && avg<49)
        System.out.println("D");
        else
        System.out.println("F");
        
        
    }
}
